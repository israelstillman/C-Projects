#include <iostream>
#include <fstream>
#include <map>
#include <algorithm>

using namespace std;

// ItemTracker class for managing item frequencies and operations
class ItemTracker {
private:
    map<string, int> itemFrequencies;

public:
    // Constructor to read item frequencies from input file
    ItemTracker() {
        ifstream inputFile("CS210_Project_Three_Input_File.txt");
        if (inputFile.is_open()) {
            string item;
            while (inputFile >> item) {
                itemFrequencies[item]++;
            }
            inputFile.close();
        }
    }

    // Function to search for the frequency of a specific item
    int searchItem(const string& item) {
        if (itemFrequencies.count(item) > 0) {
            return itemFrequencies[item];
        }
        return 0;
    }

    // Function to print the list of all items with their frequencies
    void printItemList() {
        for (const auto& pair : itemFrequencies) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    // Function to print a histogram representing the item frequencies
    void printHistogram() {
        for (const auto& pair : itemFrequencies) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }

    // Function to save the item frequencies to a backup file
    void saveDataToFile() {
        ofstream outputFile("frequency.dat");
        if (outputFile.is_open()) {
            for (const auto& pair : itemFrequencies) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
        }
    }
};

int main() {
    ItemTracker itemTracker;

    int option;
    do {
        // Print menu options
        cout << "Menu:\n";
        cout << "1. Search for an item\n";
        cout << "2. Display list of all items with frequencies\n";
        cout << "3. Display histogram\n";
        cout << "4. Exit\n";
        cout << "Enter your option: ";
        cin >> option;

        switch (option) {
        case 1: {
            string item;
            cout << "Enter the item to search for: ";
            cin >> item;

            // Convert the first letter to uppercase
            item[0] = toupper(item[0]);

            int frequency = itemTracker.searchItem(item);
            cout << "Frequency of " << item << ": " << frequency << endl;
            break;
        }
        case 2:
            itemTracker.printItemList();
            break;
        case 3:
            itemTracker.printHistogram();
            break;
        case 4:
            itemTracker.saveDataToFile();
            cout << "Data saved to frequency.dat. Exiting the program.\n";
            break;
        default:
            cout << "Invalid option. Please try again.\n";
        }
        cout << endl;
    } while (option != 4);

    return 0;
}
